# Roadmap

## Phase 1
- Server
- Data
- Documentation

## Phase 2
- Client
- Discovery Map
- Explorer
- Launcher
