# MajorMud - Reforged Documentation

Public roadmap, design decisions, research, and community collaboration.

## Goals
- Preserve original gameplay
- Modernize the engine
- Data-driven architecture
- Document design decisions
- Preserve historical MajorMUD knowledge
