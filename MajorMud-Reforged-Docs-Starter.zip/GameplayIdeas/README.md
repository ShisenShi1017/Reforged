# Gameplay Ideas

- Discovery Map
- In-Game Explorer
- Multi-character Launcher
