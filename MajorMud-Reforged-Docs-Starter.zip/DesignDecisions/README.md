# Design Decisions

DD-0001 Canonical Data
DD-0002 Reference Sources
DD-0003 Knowledge Base
DD-0004 Discussion Documentation
